package desginerPatternSingleton.main;

import desginerPatternSingleton.model.*;

public class aviaoSingletonEnumInstanceTest {
	
	public static void main(String args[]) {
		aviaoSingleEnumInstance.agendarAssento("A1");
		aviaoSingleEnumInstance.agendarAssento("A1");
		}
}
